import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class NewTaskPage extends StatefulWidget {
  final Function(String title, String category, List<Map<String, dynamic>> tasks) onTaskAdded;

  NewTaskPage({required this.onTaskAdded});

  @override
  _NewTaskPageState createState() => _NewTaskPageState();
}

class _NewTaskPageState extends State<NewTaskPage> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController taskController = TextEditingController();
  String selectedCategory = "Work";
  List<Map<String, dynamic>> checklist = [];

  void addTaskToChecklist() {
    if (taskController.text.isNotEmpty) {
      setState(() {
        checklist.add({'task': taskController.text, 'completed': false});
        taskController.clear();
      });
    }
  }

  void removeTaskFromChecklist(int index) {
    setState(() {
      checklist.removeAt(index);
    });
  }

  void toggleTaskCompletion(int index) {
    setState(() {
      checklist[index]['completed'] = !checklist[index]['completed'];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'New Task',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Colors.indigoAccent,
        elevation: 4,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.add_alert, color: Colors.white),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Reminder feature coming soon!")),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: titleController,
              style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold),
              decoration: InputDecoration(
                hintText: "Task Title",
                hintStyle: GoogleFonts.poppins(color: Colors.grey),
                border: InputBorder.none,
              ),
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.category, color: Colors.indigoAccent),
                SizedBox(width: 10),
                DropdownButton<String>(
                  value: selectedCategory,
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedCategory = newValue!;
                    });
                  },
                  items: ["Work", "Personal", "Shopping", "Others"].map((category) {
                    return DropdownMenuItem<String>(
                      value: category,
                      child: Text(
                        category,
                        style: GoogleFonts.poppins(),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: taskController,
                    decoration: InputDecoration(
                      hintText: "Enter task item...",
                      hintStyle: GoogleFonts.poppins(fontSize: 16, color: Colors.grey),
                      border: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.indigoAccent),
                      ),
                      filled: true,
                      fillColor: Colors.grey[100],
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                  ),
                ),
                SizedBox(width: 8),
                ElevatedButton(
                  onPressed: addTaskToChecklist,
                  child: Icon(Icons.add, color: Colors.white, size: 18),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.indigoAccent,
                    shape: CircleBorder(),
                    padding: EdgeInsets.all(10),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Expanded(
              child: AnimatedSwitcher(
                duration: Duration(milliseconds: 300),
                child: checklist.isEmpty
                    ? Center(
                        child: Text(
                          "No tasks added yet!",
                          style: GoogleFonts.poppins(fontSize: 16, color: Colors.grey),
                        ),
                      )
                    : ListView.builder(
                        itemCount: checklist.length,
                        itemBuilder: (context, index) {
                          return Column(
                            children: [
                              Dismissible(
                                key: Key(checklist[index]['task']),
                                direction: DismissDirection.endToStart,
                                background: Container(
                                  color: Colors.red,
                                  alignment: Alignment.centerRight,
                                  padding: EdgeInsets.symmetric(horizontal: 20),
                                  child: Icon(Icons.delete, color: Colors.white),
                                ),
                                onDismissed: (direction) {
                                  removeTaskFromChecklist(index);
                                },
                                child: ListTile(
                                  leading: Checkbox(
                                    activeColor: Colors.indigoAccent,
                                    value: checklist[index]['completed'],
                                    onChanged: (value) => toggleTaskCompletion(index),
                                  ),
                                  title: Text(
                                    checklist[index]['task'],
                                    style: GoogleFonts.poppins(
                                      fontSize: 16,
                                      decoration: checklist[index]['completed']
                                          ? TextDecoration.lineThrough
                                          : TextDecoration.none,
                                      color: checklist[index]['completed'] ? Colors.grey : Colors.black,
                                    ),
                                  ),
                                  trailing: IconButton(
                                    icon: Icon(Icons.delete, color: const Color.fromARGB(255, 104, 104, 104)),
                                    onPressed: () => removeTaskFromChecklist(index),
                                  ),
                                ),
                              ),
                              Divider(color: Colors.grey),
                            ],
                          );
                        },
                      ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton.icon(
          onPressed: () {
            if (titleController.text.isNotEmpty) {
              widget.onTaskAdded(titleController.text, selectedCategory, checklist); // Kirim data ke callback
              Navigator.pop(context);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Task title cannot be empty")),
              );
            }
          },
          icon: Icon(Icons.save, color: Colors.white),
          label: Text(
            "Save Task",
            style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(vertical: 16),
            backgroundColor: Colors.indigoAccent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
      ),
    );
  }
}