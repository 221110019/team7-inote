import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class NotesPage extends StatefulWidget {
  final List<Map<String, String>> initialNotes;
  final Function(String title, String content) onNoteAdded;

  NotesPage({
    required this.initialNotes,
    required this.onNoteAdded,
  });

  @override
  _NotesPageState createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  late List<Map<String, String>> notes;

  @override
  void initState() {
    super.initState();
    notes = List.from(widget.initialNotes);
  }

  void _addNoteDialog() {
    String title = '';
    String content = '';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add New Note'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(hintText: 'Title'),
                onChanged: (value) => title = value,
              ),
              TextField(
                decoration: InputDecoration(hintText: 'Content'),
                onChanged: (value) => content = value,
                maxLines: 3,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                if (title.isNotEmpty || content.isNotEmpty) {
                  setState(() {
                    notes.add({'title': title, 'content': content});
                  });
                  widget.onNoteAdded(title, content);
                }
                Navigator.of(context).pop();
              },
              child: Text("Add"),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  Widget _buildNoteCard(Map<String, String> note) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(Icons.note, color: Colors.indigo),
        title: Text(note['title'] ?? '', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        subtitle: Text(note['content'] ?? '', style: GoogleFonts.poppins()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Notes', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.indigoAccent,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: _addNoteDialog,
          ),
        ],
      ),
      body: notes.isNotEmpty
          ? ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: notes.length,
              itemBuilder: (context, index) {
                return _buildNoteCard(notes[index]);
              },
            )
          : Center(
              child: Text(
                "No notes yet",
                style: GoogleFonts.poppins(fontSize: 16, color: Colors.grey),
              ),
            ),
    );
  }
}
