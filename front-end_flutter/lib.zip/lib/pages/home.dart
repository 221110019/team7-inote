import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:inote/pages/tambahnotes.dart';
import 'package:inote/pages/tambahtasks.dart';
import 'package:inote/pages/notes.dart';

class NotesHomePage extends StatefulWidget {
  final List<Map<String, String>> recentItems;
  final Function(String title, String type, [String content]) onAddRecent;

  NotesHomePage({required this.recentItems, required this.onAddRecent});

  @override
  _NotesHomePageState createState() => _NotesHomePageState();
}

class _NotesHomePageState extends State<NotesHomePage> {
  List<Map<String, String>> recentItems = [];
  TextEditingController scratchPadController = TextEditingController();

  void addRecentItem(String title, String type, [String content = ""]) {
    setState(() {
      recentItems.add({'title': title, 'type': type, 'content': content});
    });
  }

  void convertToNote() {
    if (scratchPadController.text.isNotEmpty) {
      addRecentItem(scratchPadController.text, 'Note');
      scratchPadController.clear();
    }
  }

  void clearScratchPad() {
    scratchPadController.clear();
  }

  @override
  Widget build(BuildContext context) {
    String formattedDate = DateFormat('EEEE, MMMM d, yyyy').format(DateTime.now());

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Guest',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Colors.indigoAccent,
        elevation: 4,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  Text(
                    'My iNotes',
                    style: GoogleFonts.poppins(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.indigoAccent,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    formattedDate,
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: TextField(
                decoration: InputDecoration(
                  hintText: "Find any note or task",
                  hintStyle: GoogleFonts.poppins(color: Colors.grey),
                  border: InputBorder.none,
                  icon: Icon(Icons.search, color: Colors.grey),
                ),
              ),
            ),
            SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSelectionBox(
                  context,
                  icon: Icons.note_add,
                  label: "New Note",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => NewNotePage(
                          onNoteAdded: (title, content) {
                            addRecentItem(title, 'Note', content);
                          },
                        ),
                      ),
                    );
                  },
                ),
                _buildSelectionBox(
                  context,
                  icon: Icons.task,
                  label: "New Task",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => NewTaskPage(
                          onTaskAdded: (title, category, checklist) {
                            addRecentItem(title, 'Task');
                          },
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: 30),
            Text(
              "Recent Notes & Tasks",
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: recentItems.isNotEmpty
                  ? ListView.builder(
                      itemCount: recentItems.length,
                      itemBuilder: (context, index) {
                        return Card(
                          elevation: 2,
                          margin: EdgeInsets.symmetric(vertical: 5),
                          child: ListTile(
                            leading: Icon(
                              recentItems[index]['type'] == 'Note'
                                  ? Icons.note
                                  : Icons.check_circle,
                              color: Colors.indigoAccent,
                            ),
                            title: Text(
                              recentItems[index]['title']!,
                              style: GoogleFonts.poppins(),
                            ),
                            subtitle: Text(
                              recentItems[index]['type']!,
                              style: GoogleFonts.poppins(color: Colors.grey),
                            ),
                            onTap: () async {
                              if (recentItems[index]['type'] == 'Note') {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => NotesPage(
                                      initialNotes: recentItems
                                          .where((item) => item['type'] == 'Note')
                                          .map((e) => {
                                                'title': e['title']!,
                                                'content': e['content'] ?? '',
                                              })
                                          .toList(),
                                      onNoteAdded: (title, content) {
                                        addRecentItem(title, 'Note', content);
                                      },
                                    ),
                                  ),
                                );
                                setState(() {}); // refresh jika ada perubahan
                              }
                            },
                          ),
                        );
                      },
                    )
                  : Center(
                      child: Text(
                        "No notes or tasks yet",
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          color: Colors.grey,
                        ),
                      ),
                    ),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Scratch Pad",
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[700],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'convert') {
                      convertToNote();
                    } else if (value == 'clear') {
                      clearScratchPad();
                    }
                  },
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 'convert',
                      child: Row(
                        children: [
                          Icon(Icons.note_add, color: Colors.indigoAccent),
                          SizedBox(width: 12),
                          Text(
                            "Convert to note",
                            style: GoogleFonts.poppins(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: Colors.indigoAccent,
                            ),
                          ),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'clear',
                      child: Row(
                        children: [
                          Icon(Icons.delete_forever, color: Colors.redAccent),
                          SizedBox(width: 12),
                          Text(
                            "Clear all",
                            style: GoogleFonts.poppins(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: Colors.redAccent,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 10),
            Container(
              height: 150,
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: TextField(
                controller: scratchPadController,
                maxLines: 5,
                decoration: InputDecoration(
                  hintText: "Write a temporary note...",
                  border: InputBorder.none,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectionBox(BuildContext context,
      {required IconData icon, required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 150,
        height: 150,
        decoration: BoxDecoration(
          color: Colors.indigoAccent,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(color: Colors.black26, blurRadius: 5, spreadRadius: 2),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.white),
            SizedBox(height: 10),
            Text(
              label,
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
