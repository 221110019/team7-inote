import 'package:flutter/material.dart';

class TasksPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tasks')),
      body: Center(
        child: Text('Daftar Tugas', style: TextStyle(fontSize: 20)),
      ),
    );
  }
}
