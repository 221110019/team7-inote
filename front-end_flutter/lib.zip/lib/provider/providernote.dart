import 'package:flutter/material.dart';

class NoteProvider with ChangeNotifier {
  final List<Map<String, String>> _notes = [];

  List<Map<String, String>> get notes => List.unmodifiable(_notes);

  void addNote(String title, String content) {
    _notes.add({'title': title, 'content': content});
    notifyListeners();
  }
}
