import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:inote/pages/home.dart';
import 'package:inote/pages/notes.dart';
import 'package:inote/pages/tasks.dart';

class BottomNavBar extends StatefulWidget {
  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  int _selectedIndex = 0;

  List<Map<String, String>> recentItems = [];

  void addRecentItem(String title, String type, [String content = ""]) {
    setState(() {
      recentItems.add({'title': title, 'type': type, 'content': content});
    });
  }

  List<Widget> get _pages => [
        NotesHomePage(
          recentItems: recentItems,
          onAddRecent: addRecentItem,
        ),
        NotesPage(
          initialNotes: recentItems
              .where((item) => item['type'] == 'Note')
              .map((e) => {
                    'title': e['title']!,
                    'content': e['content'] ?? '',
                  })
              .toList(),
          onNoteAdded: (title, content) {
            addRecentItem(title, 'Note', content);
          },
        ),
        TasksPage(),
      ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.note),
            label: 'Notes',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.checklist),
            label: 'Tasks',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.indigoAccent,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        backgroundColor: Colors.white,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.bold,
        ),
        unselectedLabelStyle: GoogleFonts.poppins(
          fontSize: 12,
          fontWeight: FontWeight.normal,
        ),
      ),
    );
  }
}
